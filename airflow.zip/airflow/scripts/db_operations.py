import mysql.connector
import logging
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def get_db_connection():
    """
    Establish a database connection using the config file.
    """
    try:
        with open('config/db_config.json') as config_file:
            config = json.load(config_file)
        return mysql.connector.connect(
            host=config["host"],
            user=config["user"],
            password=config["password"],
            database=config["database"],
            port=config["port"]
        )
    except (FileNotFoundError, KeyError, json.JSONDecodeError) as e:
        logging.error(f"Error loading database configuration: {e}")
        raise

def create_tables():
    """
    Create the required database tables.
    """
    query = """
    CREATE TABLE IF NOT EXISTS posts (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT,
        title VARCHAR(255),
        body TEXT
    );
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
        logging.info("Table `posts` created successfully.")
    except mysql.connector.Error as e:
        logging.error(f"Error creating table: {e}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

def insert_data(data):
    """
    Insert data into the database.
    """
    query = """
    INSERT INTO posts (user_id, title, body) VALUES (%s, %s, %s);
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        for entry in data:
            cursor.execute(query, (entry['userId'], entry['title'], entry['body']))
        conn.commit()
        logging.info(f"Inserted {cursor.rowcount} records into the database.")
    except mysql.connector.Error as e:
        logging.error(f"Error inserting data: {e}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
