import requests
import logging

def fetch_api_data(api_url):
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        logging.info("Successfully fetched data from API.")
        return data
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching API data: {e}")
        return None

if __name__ == "__main__":
    sample_api = "https://jsonplaceholder.typicode.com/posts"
    data = fetch_api_data(sample_api)
    if data:
        print(data[:5])  # Log a portion of the data for verification
