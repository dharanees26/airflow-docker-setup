import sys
import os
import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

# Add the scripts directory to the Python path (assuming 'scripts' is at the root of your project)
sys.path.append(os.path.join(os.path.dirname(__file__), "../scripts"))

from fetch_data import fetch_api_data
from db_operations import create_tables, insert_data

# Set up logging
logger = logging.getLogger(__name__)

default_args = {
    'owner': 'airflow',
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

def fetch_and_store():
    logger.info("Starting fetch_and_store task...")
    api_url = "https://jsonplaceholder.typicode.com/posts"
    data = fetch_api_data(api_url)

    if data:
        logger.info(f"Fetched {len(data)} records from API.")
        insert_data(data)
    else:
        logger.warning("No data fetched from the API.")

# Define the DAG
with DAG(
    'real_time_data_ingestion',
    default_args=default_args,
    description='A DAG for ingesting data from an API to Mysql',
    schedule_interval='@hourly',
    start_date=datetime(2023, 12, 1),
    catchup=False,
) as dag:

    # Task 1: Create database tables
    create_db_task = PythonOperator(
        task_id='create_db',
        python_callable=create_tables,
    )

    # Task 2: Fetch and store data
    ingest_data_task = PythonOperator(
        task_id='fetch_and_store_data',
        python_callable=fetch_and_store,
    )

    # Define task dependencies
    create_db_task >> ingest_data_task
